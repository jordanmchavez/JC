﻿#include "JC/Unicode.h"
#include "JC/Unit.h"
#include <wchar.h>

namespace JC::Unicode {

//--------------------------------------------------------------------------------------------------

constexpr U32 ConstExprWStrLen(wchar_t const* s) {
	if (s == nullptr) {
		return 0;
	}
	wchar_t const* p = s;
	while (*p) {
		++p;
	}
	return (U32)(p - s);
}

bool operator==(Span<wchar_t>  s1, wchar_t const* s2) { return !wcscmp(s1.data, s2); }
bool operator==(wchar_t const* s1, Span<wchar_t>  s2) { return !wcscmp(s1, s2.data);  }

//--------------------------------------------------------------------------------------------------

Span<wchar_t> Utf8ToWtf16z(Mem mem, Str s) {
	// Max WTF-16 encoding of a UTF-8 string is 2*len(utf8Str)
	wchar_t* const out = Mem::AllocT<wchar_t>(mem, (s.len * 2) + 1);
	U64 outLen = 0;

	U8 const* p = (U8 const*)s.data;
	U8 const* end = p + s.len;
	while (p < end) {
		// U+ 0000 - U+ 007f | 0xxxyyyy                            | 0x00 - 0x7f
		// U+ 0080 - U+ 07ff | 110xxxyy 10yyzzzz                   | 0xc2 - 0xdf
		// U+ 0800 - U+ ffff | 1110xxxx 10uuuuzz 10zzuuuu          | 0xe0 - 0xef
		// U+10000 - U+10fff | 11110xyy 10yyzzzz 10uuuuvv 10vvwwww | 0xf0 - 0xf7

		// surrogates
		// U+d800 | 111011011010000010000000 | ed a0 80
		// U+dbff | 111011011010111110111111 | ed af bf
		// U+dc00 | 111011011011000010000000 | ed b0 80
		// U+dfff | 111011011011111110111111 | ed bf bf

		// illegal:
		// 0x80 - 0xbf
		// 0xf8 - 0xff

		U32 cp = (U32)L'?';
		U32 const c1 = (U32)*p++;
		if (c1 <= 0x7f) {
			cp = (U32)c1;

		} else if (c1 >= 0xc2 && c1 <= 0xdf) {
			if (p > end) { out[outLen++] = L'?'; break; }
			U32 const c2 = (U32)*p++;
			if (c2 < 0x80 || c2 > 0xbf) { out[outLen++] = L'?'; continue; }
			cp = ((c1 & 0x1f) << 6) + (c2 & 0x3f);

		} else if (c1 <= 0xef) {
			if (p + 1 > end) { out[outLen++] = L'?'; break; }
			U32 const c2 = (U32)*p++;
			U32 const c3 = (U32)*p++;
			if (c1 == 0xe0) {
				if (c2 < 0xa0 || c2 > 0xbf) { out[outLen++] = L'?'; continue; }
			} else {
				if (c2 < 0x80 || c2 > 0xbf) { out[outLen++] = L'?'; continue; }
			}
			if (c3 < 0x80 || c3 > 0xbf) { out[outLen++] = L'?'; continue; }
			cp = ((c1 & 0xf) << 12) + ((c2 & 0x3f) << 6) + (c3 & 0x3f);

		} else if (c1 <= 0xf4) {
			if (p + 2 > end) {
				out[outLen++] = L'?';
				break;
			}
			U32 const c2 = (U32)*p++;
			U32 const c3 = (U32)*p++;
			U32 const c4 = (U32)*p++;
			if (c1 == 0xf0) {
				if (c2 < 0x90 || c2 > 0xbf) { out[outLen++] = L'?'; continue; }
			} else if (c1 >= 0xf1 && c1 <= 0xf3) {
				if (c2 < 0x80 || c2 > 0xbf) { out[outLen++] = L'?'; continue; }
			} else {
				if (c2 < 0x80 || c2 > 0x8f) { out[outLen++] = L'?'; continue; }
			}
			if (c3 < 0x80 || c3 > 0xbf) { out[outLen++] = L'?'; continue; }
			if (c4 < 0x80 || c4 > 0xbf) { out[outLen++] = L'?'; continue; }
			cp = ((c1 & 0x7) << 18) + ((c2 & 0x3f) << 12) + ((c3 & 0x3f) << 6) + (c4 & 0x3f);

		} else {
			out[outLen++] = L'?';
		}

		if (cp <= 0xffff) {
			out[outLen++] = (wchar_t)cp;
		} else {
			out[outLen++] = (wchar_t)((cp - 0x10000) >> 10) + 0xd800;
			out[outLen++] = (wchar_t)((cp - 0x10000) & 0x3ff) + 0xdc00;
		}
	}

	out[outLen] = u'\0';
	return Span<wchar_t>(out, outLen - 1);
}

//--------------------------------------------------------------------------------------------------

#define CheckUtf8ToWtf16z(from8, to16z) \
		Unit_Check(Utf8ToWtf16z(testMem, from8) == to16z)

Unit_Test("Utf8ToWtf16z") {
	CheckUtf8ToWtf16z("\x00", L"\x0000");
	CheckUtf8ToWtf16z("\x7f", L"\x007f");

	CheckUtf8ToWtf16z("\xc2\x80", L"\x0080");
	CheckUtf8ToWtf16z("\xc2\xbf", L"\x00bf");
	CheckUtf8ToWtf16z("\xdf\x80", L"\x07c0");
	CheckUtf8ToWtf16z("\xdf\xbf", L"\x07ff");

	CheckUtf8ToWtf16z("\xe0\xa0\x80", L"\x0800");
	CheckUtf8ToWtf16z("\xe0\xa0\xbf", L"\x083f");
	CheckUtf8ToWtf16z("\xe0\xbf\x80", L"\xfc0");
	CheckUtf8ToWtf16z("\xe0\xbf\xbf", L"\x0fff");

	CheckUtf8ToWtf16z("\xe1\x80\x80", L"\x1000");
	CheckUtf8ToWtf16z("\xe1\x80\xbf", L"\x103f");
	CheckUtf8ToWtf16z("\xe1\xbf\x80", L"\x1fc0");
	CheckUtf8ToWtf16z("\xe1\xbf\xbf", L"\x1fff");
	CheckUtf8ToWtf16z("\xef\x80\x80", L"\xf000");
	CheckUtf8ToWtf16z("\xef\x80\xbf", L"\xf03f");
	CheckUtf8ToWtf16z("\xef\xbf\x80", L"\xffc0");
	CheckUtf8ToWtf16z("\xef\xbf\xbf", L"\xffff");
	
	CheckUtf8ToWtf16z("\xf0\x90\x80\x80", L"\xd800\xdc00");
	CheckUtf8ToWtf16z("\xf0\x90\x80\xbf", L"\xd800\xdc3f");
	CheckUtf8ToWtf16z("\xf0\x90\xbf\x80", L"\xd803\xdfc0");
	CheckUtf8ToWtf16z("\xf0\x90\xbf\xbf", L"\xd803\xdfff");
	CheckUtf8ToWtf16z("\xf0\xbf\x80\x80", L"\xd8bc\xdc00");
	CheckUtf8ToWtf16z("\xf0\xbf\x80\xbf", L"\xd8bc\xdc3f");
	CheckUtf8ToWtf16z("\xf0\xbf\xbf\x80", L"\xd8bf\xdfc0");
	CheckUtf8ToWtf16z("\xf0\xbf\xbf\xbf", L"\xd8bf\xdfff");

	CheckUtf8ToWtf16z("\xf1\x80\x80\x80", L"\xd8c0\xdc00");
	CheckUtf8ToWtf16z("\xf1\x80\x80\xbf", L"\xd8c0\xdc3f");
	CheckUtf8ToWtf16z("\xf1\x80\xbf\x80", L"\xd8c3\xdfc0");
	CheckUtf8ToWtf16z("\xf1\x80\xbf\xbf", L"\xd8c3\xdfff");

	CheckUtf8ToWtf16z("\xf1\xbf\x80\x80", L"\xd9bc\xdc00");
	CheckUtf8ToWtf16z("\xf1\xbf\x80\xbf", L"\xd9bc\xdc3f");
	CheckUtf8ToWtf16z("\xf1\xbf\xbf\x80", L"\xd9bf\xdfc0");
	CheckUtf8ToWtf16z("\xf1\xbf\xbf\xbf", L"\xd9bf\xdfff");

	CheckUtf8ToWtf16z("\xf3\x80\x80\x80", L"\xdac0\xdc00");
	CheckUtf8ToWtf16z("\xf3\x80\x80\xbf", L"\xdac0\xdc3f");
	CheckUtf8ToWtf16z("\xf3\x80\xbf\x80", L"\xdac3\xdfc0");
	CheckUtf8ToWtf16z("\xf3\x80\xbf\xbf", L"\xdac3\xdfff");

	CheckUtf8ToWtf16z("\xf3\xbf\x80\x80", L"\xdbbc\xdc00");
	CheckUtf8ToWtf16z("\xf3\xbf\x80\xbf", L"\xdbbc\xdc3f");
	CheckUtf8ToWtf16z("\xf3\xbf\xbf\x80", L"\xdbbf\xdfc0");
	CheckUtf8ToWtf16z("\xf3\xbf\xbf\xbf", L"\xdbbf\xdfff");

	CheckUtf8ToWtf16z("\xf4\x80\x80\x80", L"\xdbc0\xdc00");
	CheckUtf8ToWtf16z("\xf4\x80\x80\xbf", L"\xdbc0\xdc3f");
	CheckUtf8ToWtf16z("\xf4\x80\xbf\x80", L"\xdbc3\xdfc0");
	CheckUtf8ToWtf16z("\xf4\x80\xbf\xbf", L"\xdbc3\xdfff");
	CheckUtf8ToWtf16z("\xf4\x8f\x80\x80", L"\xdbfc\xdc00");
	CheckUtf8ToWtf16z("\xf4\x8f\x80\xbf", L"\xdbfc\xdc3f");
	CheckUtf8ToWtf16z("\xf4\x8f\xbf\x80", L"\xdbff\xdfc0");
	CheckUtf8ToWtf16z("\xf4\x8f\xbf\xbf", L"\xdbff\xdfff");

	CheckUtf8ToWtf16z((char const*)u8"hello, nice to meet you abcʦϧ턖릇块𒃶𒅋🀅🚉🤸", L"hello, nice to meet you abcʦϧ턖릇块𒃶𒅋🀅🚉🤸");
}

//--------------------------------------------------------------------------------------------------

Str Wtf16zToUtf8(Mem mem, wchar_t const* s) {
	// Max UTF-8 encoding of a WTF-16 string is len(wtf16Str) * 3, due to BMP chars/unpaired surrogates
	const U64 len = wcslen(s);
	char* out = Mem::AllocT<char>(mem, len * 3);	
	U32 outLen = 0;

	wchar_t const* p = s;
	while (*p) {
		U32 cp;
		U32 const c = (U32)*p++;
		if (c <= 0xd7ff || c >= 0xe000) {
			cp = c;
		} else if (c <= 0xdbff && *p && *p >= 0xdc00 && *p <= 0xdfff) {
			cp = 0x10000 + ((c - 0xd800) << 10) + (*p - 0xdc00);
			++p;
		} else {
			cp = c;
		}

		if (cp <= 0x7f) {
			out[outLen++] = (char)cp;
		} else if (cp <= 0x7ff) {
			out[outLen++] = (char)(0xc0 | (cp >> 6));
			out[outLen++] = (char)(0x80 | (cp & 0x3f));
		} else if (cp <= 0xffff) {
			out[outLen++] = (char)(0xe0 | (cp >> 12));
			out[outLen++] = (char)(0x80 | (cp >> 6) & 0x3f);
			out[outLen++] = (char)(0x80 | (cp & 0x3f));
		} else {
			out[outLen++] = (char)(0xf0 | (cp >> 18));
			out[outLen++] = (char)(0x80 | (cp >> 12) & 0x3f);
			out[outLen++] = (char)(0x80 | (cp >> 6) & 0x3f);
			out[outLen++] = (char)(0x80 | (cp & 0x3f));
		}
	}

	return Str(out, outLen);
}

// High surrogate range
	// 1101100000000000 d800
	// 1101101111111111 dbff
// Low surrogate range
	// 1101110000000000 dc00
	// 1101111111111111 dfff

Unit_Test("Unicode::Wtf16zToUtf8") {
	#define CheckWtf16zToUtf8(from16z, to8) \
		Unit_CheckEq(Wtf16zToUtf8(testMem, from16z), to8)

	// General 
	CheckWtf16zToUtf8(L"", "");
	CheckWtf16zToUtf8(L"hello", "hello");
	CheckWtf16zToUtf8(L"hello\xd800\xdc00world", "hello\xf0\x90\x80\x80world");
	CheckWtf16zToUtf8(L"hello\xd800world", "hello\xed\xa0\x80world");

	// Invalid surrogate: end-of-string
	CheckWtf16zToUtf8(L"\xd800", "\xed\xa0\x80");
	CheckWtf16zToUtf8(L"\xdbff", "\xed\xaf\xbf");

	// 1 byte
	CheckWtf16zToUtf8(L"\x0000", "\x00");
	CheckWtf16zToUtf8(L"\x007f", "\x7f");

	// 2 bytes
	CheckWtf16zToUtf8(L"\x0080", "\xc2\x80");
	CheckWtf16zToUtf8(L"\x07ff", "\xdf\xbf");

	// 3 bytes + surrogate edge cases
	CheckWtf16zToUtf8(L"\x0800", "\xe0\xa0\x80");
	CheckWtf16zToUtf8(L"\xd7ff", "\xed\x9f\xbf");
	CheckWtf16zToUtf8(L"\xe000", "\xee\x80\x80");
	CheckWtf16zToUtf8(L"\xffff", "\xef\xbf\xbf");

	// 4 bytes + surrogate edge cases
	CheckWtf16zToUtf8(L"\xd800\xdc00", "\xf0\x90\x80\x80");
	CheckWtf16zToUtf8(L"\xd800\xdfff", "\xf0\x90\x8f\xbf");
	CheckWtf16zToUtf8(L"\xdbff\xdc00", "\xf4\x8f\xb0\x80");
	CheckWtf16zToUtf8(L"\xdbff\xdfff", "\xf4\x8f\xbf\xbf");

	// Invalid surrogate: bad low surrogate
	CheckWtf16zToUtf8(L"\xd800\x0000", "\xed\xa0\x80\x00");
	CheckWtf16zToUtf8(L"\xd800\xd7ff", "\xed\xa0\x80\xed\x9f\xbf");
	CheckWtf16zToUtf8(L"\xd800\xd800", "\xed\xa0\x80\xed\xa0\x80");
	CheckWtf16zToUtf8(L"\xd800\xdbff", "\xed\xa0\x80\xed\xaf\xbf");
	CheckWtf16zToUtf8(L"\xd800\xe000", "\xed\xa0\x80\xee\x80\x80");
	CheckWtf16zToUtf8(L"\xd800\xffff", "\xed\xa0\x80\xef\xbf\xbf");

	// Invalid surrogate: bad high surrogate
	CheckWtf16zToUtf8(L"\xdc00\xdc00", "\xed\xb0\x80\xed\xb0\x80");
	CheckWtf16zToUtf8(L"\xdfff\xdc00", "\xed\xbf\xbf\xed\xb0\x80");
}

//--------------------------------------------------------------------------------------------------

}	// namespace JC::Unicode